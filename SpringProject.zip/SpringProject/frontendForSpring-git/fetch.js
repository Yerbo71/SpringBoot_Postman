document.getElementById("myForm").addEventListener("submit", function(event) {
    event.preventDefault(); // Предотвратите стандартную отправку формы
  
    // Получите данные из формы
    const formData = new FormData(document.getElementById("myForm"));
    const data = {
      name: formData.get("username"),
      email: formData.get("email"),
      age: formData.get("age"),
      password: formData.get("password")
    };
  
    // Отправьте данные на сервер
    sendDataToBackend(data);
  });
  
  function sendDataToBackend(data) {
    fetch("http://localhost:9091/api/v1/customers", {
      method: "POST", // Используйте "POST" для отправки данных на сервер
      body: JSON.stringify(data), // Преобразуйте данные в JSON
      headers: {
        "Content-Type": "application/json"
      }
    })
      .then(response => {
        if (response.ok) {
          return response.json();
        } else {
          throw new Error("Ошибка при отправке данных на сервер");
        }
      })
      .then(responseData => {
        console.log("Данные успешно отправлены на сервер:", responseData);
        // Вы можете добавить дополнительную обработку здесь, если это необходимо
      })
      .catch(error => {
        console.error("Ошибка:", error);
      });
  }

