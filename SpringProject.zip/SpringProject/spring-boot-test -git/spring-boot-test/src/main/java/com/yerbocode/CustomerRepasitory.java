package com.yerbocode;

import org.springframework.data.jpa.repository.JpaRepository;

public interface CustomerRepasitory
        extends JpaRepository<Customer,Integer> {
}
