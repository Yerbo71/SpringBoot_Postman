package com.yerbocode;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@SpringBootApplication
@RestController
@CrossOrigin(origins = "http://127.0.0.1:5500")
@RequestMapping("api/v1/customers")
public class Main {
    private final CustomerRepasitory customerRepasitory;

    public Main(CustomerRepasitory customerRepasitory) {
        this.customerRepasitory = customerRepasitory;
    }

    public static void main(String[] args) {
        SpringApplication.run(Main.class, args);
    }

    @GetMapping
    public List<Customer> getCustomers() {
        return customerRepasitory.findAll();
    }

    record NewCustomerRequest(
            String name,
            String email,
            Integer age,
            String password
    ) {

    }

    @PostMapping
    public void addCustomer(@RequestBody NewCustomerRequest request) {
        Customer customer = new Customer();
        customer.setName(request.name);
        customer.setEmail(request.email);
        customer.setAge(request.age);
        customer.setPassword(request.password);
        customerRepasitory.save(customer);

    }

    @DeleteMapping("{customerId}")
    public void deleteCustomer(@PathVariable("customerId") Integer id) {
        customerRepasitory.deleteById(id);
    }

    @PutMapping("{customerId}")
    public void editCustomer(@PathVariable("customerId") Integer id, @RequestBody NewCustomerRequest request) {
        Customer customer = customerRepasitory.getReferenceById(id);
        if (request.name != null) {
            customer.setName(request.name);
        }
        if (request.age != null) {
            customer.setAge(request.age);
        }
        if (request.email != null) {
            customer.setEmail(request.email);
        }
        if (request.password != null) {
            customer.setEmail(request.email);
        }
        customerRepasitory.save(customer);
    }
}


